declare module 'react-image-cropper';
declare module 'react-jss/lib/JssProvider';
declare module '*.png';
