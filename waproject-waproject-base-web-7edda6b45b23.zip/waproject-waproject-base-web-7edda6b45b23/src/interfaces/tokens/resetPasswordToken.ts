export default interface IResetPasswordToken {
  id: number;
  firstName: string;
  email: string;
}
