export default interface ISelectItem<T = string> {
  value: T;
  label: string;
}
