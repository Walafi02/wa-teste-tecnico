export function apiRequestFormatter<T>(obj: T): T {
  return obj;
}
