TESTES
======

Os teste utilizam mocha com chai, e sqlite para rodar.
Já esta configurado para não deixar gerar a imagem de produção
sem passar nos testes antes.

### Rodar

```bash
yarn test # or npm run test
```

### Desenvolvimento

Para facilitar o desenvolvimento utilize o comando abaixo,
ele dará watch nos arquivos.

```bash
yarn test:watch # or npm run test:watch
```