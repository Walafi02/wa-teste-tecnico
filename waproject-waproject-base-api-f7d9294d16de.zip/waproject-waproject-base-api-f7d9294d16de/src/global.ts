import 'app-module-path/register';

// eslint-disable-next-line @typescript-eslint/no-require-imports
require('source-map-support').install({ hookRequire: true });
