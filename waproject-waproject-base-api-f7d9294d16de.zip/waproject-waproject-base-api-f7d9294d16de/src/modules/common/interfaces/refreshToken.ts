export interface IRefreshToken {
  userId: number;
  deviceId: string;
  uuid: string;
}
